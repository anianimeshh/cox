package com.example.MyWebApp;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dto.Collector;
import com.example.dto.Collectors;
import com.example.dto.IpdrProxy;
import com.example.dto.Proxy;
import com.example.dto.Sessions;

@Controller
public class Unmarshalling extends HttpServlet{ 

	@RequestMapping("ipdr3")
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(IpdrProxy.class);

			Unmarshaller unmarshaller = context.createUnmarshaller();
			IpdrProxy px = (IpdrProxy) unmarshaller.unmarshal(new FileReader("C:/Users/animdas/Desktop/item3.xml"));
			out.println("<html ><head><style>");
			out.println("table, th, td {border: 1px solid black;}");
			out.println("input[type=text] {width: 100%;}");

			out.println("</style></head>");
			out.println("<body>");   //<body bgcolor="#ccc121">


			out.println("<center>");

			out.println("<form  action=\"./marshal2\" method=\"post\">");
			out.println("<table width=100% cellspacing=\"0.1\"><tr><th>Count</th><th>remote-addr</th><th>local-addr</th><th>name</th><th>name</th><th>addr</th><th>priority</th><th>addr</th><th>priority</th></tr>");

			int a=0;
			ArrayList<Proxy> list3 = px.getProxy();
			for(Proxy prok : list3)
			{
				a++;
				out.println("<tr>");
				//<input type="submit" value="submit">

				out.println("<td>"+a+"</td>");
				out.println("<td>"+"<input type=\"text\" name=\"v1\" value="+prok.getRemote_addr()+">"+"</td>");
				out.println("<td>"+"<input type=\"text\" name=\"v2\" value="+prok.getLocal_addr()+">"+"</td>");

				//out.println("<td>"+prok.getLocal_addr()+"</td>");
				ArrayList<Sessions> list = prok.getSessions();


				for (Sessions sess : list) 
				{
					out.println("<td>"+"<input type=\"text\" name=\"v3\" value="+sess.getName()+">"+"</td>");

					//out.println("<td>"+sess.getName()+"</td>");

					ArrayList<Collectors> list1 = sess.getCollectors();

					for(Collectors collect:list1)
					{
						out.println("<td>"+"<input type=\"text\" name=\"v4\" value="+collect.getName()+">"+"</td>");

						//out.println("<td>"+collect.getName()+"</td>");

						ArrayList<Collector> list2 = collect.getCollector(); 
						int i=5;
						for(Collector collect1 : list2)
						{
							out.println("<td>"+"<input type=\"text\" name=\"v"+i+"\" value="+collect1.getAddr()+">"+"</td>");
							i++;
							out.println("<td>"+"<input type=\"text\" name=\"v"+i+"\" value="+collect1.getPriority()+">"+"</td>");
							i++;
							//out.println("<td>"+collect1.getAddr()+"</td>");
							//out.println("<td>"+collect1.getPriority()+"</td>");
						}

					}

				}

				out.println("</tr>");

			}

			out.println("</table>");
			out.println("<input type=Submit name=s1>");


			out.println("</form>");
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}