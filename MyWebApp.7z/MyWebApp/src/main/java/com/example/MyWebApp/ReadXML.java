package com.example.MyWebApp;

import java.io.*;
import org.w3c.dom.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.xml.parsers.*;
import javax.servlet.http.*;



@WebServlet("/ipdr")
public class ReadXML extends HttpServlet{ 
    public boolean isTextNode(Node n){
    return n.getNodeName().equals("#text");
    }
        public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try{
        DocumentBuilderFactory docFactory =  DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.parse("C:/Users/animdas/Desktop/item.xml");
        out.println("<table border=2><tr><th>Account</th><th>Name</th><th>Note</th><th>CodeNo</th><th>Source</th></tr>");
        Element  element = doc.getDocumentElement(); 
        NodeList personNodes = element.getChildNodes(); 
        for (int i=0; i<personNodes.getLength(); i++){
        Node emp = personNodes.item(i);
        if (isTextNode(emp))
         continue;
        NodeList NameDOBCity = emp.getChildNodes(); 
        out.println("<tr>");
        for (int j=0; j<NameDOBCity.getLength(); j++ ){
        Node node = NameDOBCity.item(j);
        if ( isTextNode(node)) 
        continue;
        out.println("<td>"+(node.getFirstChild().getNodeValue())+"</td>");
        } 
        out.println("</tr>");
        }
        out.println("</table>");
        }
        catch(Exception e){
            System.out.println(e);
        }
        }
}