package com.example.MyWebApp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dto.Collector;
import com.example.dto.Collectors;
import com.example.dto.IpdrProxy;
import com.example.dto.Proxy;
import com.example.dto.Sessions;

//@RequestMapping("/marshal2")
@Controller
public class Marshalling extends HttpServlet
{
	@RequestMapping("marshal2")
	public void doPost (HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
//		 String configFileName = "C:/Users/animdas/Desktop/item5.xml";
//	        File configFile = new File(Marshalling.class.getResource(configFileName).getFile());
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(IpdrProxy.class);
			Marshaller marshaller= context.createMarshaller();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, new Boolean(true));
		
		
		PrintWriter out = response.getWriter();

		  String remote_addr[] = request.getParameterValues("v1");
		  String local_addr[] = request.getParameterValues("v2");
		  String name1[] = request.getParameterValues("v3");
		  String name2[] = request.getParameterValues("v4");
		  String addr1[] = request.getParameterValues("v5");
		  String priority1[] =request.getParameterValues("v6");
		  String addr2[] = request.getParameterValues("v7");
		  String priority2[] =request.getParameterValues("v8");
		for(int i=0;i<remote_addr.length;i++)
		
		{
			out.println(remote_addr[i]);
			out.println(local_addr[i]);
			out.println(name1[i]);
			out.println(name2[i]);
			out.println(addr1[i]);
			out.println(priority1[i]);
			out.println(addr2[i]);
			out.println(priority2[i]);

			//collector class  
			ArrayList<Collector> collect = new ArrayList<Collector>();
	
			Collector col1 = new Collector()	;
			col1.setAddr(addr1[i]);
			col1.setPriority(priority1[i]);
			collect.add(col1);
	
			Collector col2 = new Collector()	;
			col2.setAddr(addr2[i]);
			col2.setPriority(priority2[i]);
			collect.add(col2);
	
	
			// Collectors class
			ArrayList<Collectors> coll = new ArrayList<Collectors>();
			Collectors col =new Collectors();
			col.setName(name2[i]);
			col.setCollector(collect);
			coll.add(col);
	
			//Sessions class
			ArrayList<Sessions> session = new ArrayList<Sessions>();  
			Sessions ses =new Sessions();
			ses.setName(name1[i]);
			ses.setCollectors(coll);
			session.add(ses);
	
			// _proxy class
			ArrayList<Proxy> prox = new ArrayList<Proxy>();
			Proxy px = new Proxy();
			px.setRemote_addr(remote_addr[i]);
			px.setLocal_addr(local_addr[i]);
			px.setSessions(session);
			prox.add(px);
	
			//IpdrProxyClass
			IpdrProxy ipprox = new IpdrProxy();
			ipprox.setProxy(prox);
			

			//_marshalling 
			

	
				
				
				marshaller.marshal(ipprox, System.out);
				//marshaller.marshal(ipprox, configFile);
				//File pr=new File("src\\data\\data.xml");
				marshaller.marshal(ipprox, new FileOutputStream("src\\data\\data.xml"));
				//marshaller.marshal(ipprox, new FileOutputStream("C:/Users/animdas/Desktop/item4.xml"));
	            //marshaller.mars
			} 
		//marshaller.marshal(ipprox, new FileOutputStream("C:/Users/animdas/Desktop/item4.xml"));
			
			
		}
		catch (JAXBException e) 
	     { // TODO Auto-generated catch block
		    e.printStackTrace(); 
		  }
		//out.println("<h1>Data printed check in notepad:)-</h1>");	
		 
		
				//		out.println("<h1>"+fname1+"</h1>");
				//		out.println("<h1>"+fname2+"</h1>");
				//		out.println("<h1>"+fname3+"</h1>");
				//		out.println("<h1>"+fname4+"</h1>");
				//		out.println("<h1>"+fname5+"</h1>");
				//		out.println("<h1>"+fname6+"</h1>");
				//		out.println("<h1>"+fname7+"</h1>");
				//		out.println("<h1>"+fname8+"</h1>");
//		Iterator<Proxy> iterator = px.setRemote_addr(remote_addr[i]).iterator();
//		while (iterator.hasNext()) {
//		    if (removeId.equals(iterator.next().getId())) {
//		         iterator.remove();
//		    }
//		}


	}
}
