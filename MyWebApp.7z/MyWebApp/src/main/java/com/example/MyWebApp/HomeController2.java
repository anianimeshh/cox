package com.example.MyWebApp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




@Controller
public class HomeController2 extends HttpServlet{ 
	public boolean isTextNode(Node n){
		return n.getNodeName().equals("#text");
	}
	@RequestMapping("ipdr1")
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try{
			DocumentBuilderFactory docFactory =  DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse("C:/Users/animdas/Desktop/item2.xml");
			out.println("<table border=2><tr><th>remote-addr</th><th>local-addr</th><th>name</th><th>name</th><th>addr</th><th>priority</th><th>addr</th><th>priority</th></tr>");
			Element  element = doc.getDocumentElement(); 
			NodeList parentNodes = element.getChildNodes(); 
			for (int i=0; i<parentNodes.getLength(); i++){
				Node item = parentNodes.item(i);
				if (isTextNode(item))
					continue;
				NodeList NameElements = item.getChildNodes(); 
				out.println("<tr>");
				for (int j=0; j<NameElements.getLength(); j++ ){
					Node node = NameElements.item(j);
					if ( isTextNode(node)) 
						continue;
					out.println("<td>"+(node.getFirstChild().getNodeValue())+"</td>");
				} 
				out.println("</tr>");
			}
			out.println("</table>");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}