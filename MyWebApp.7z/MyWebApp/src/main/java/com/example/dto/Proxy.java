package com.example.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlElementWrapper(name="sessions", required=true)
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)

public class Proxy

{

	//@XmlElementWrapper(name="sessions", required=true)
	@XmlElement(name="remote-addr")

	private String remote_addr;
	@XmlElement(name="local-addr")
	private String local_addr;

	@XmlElement(name="sessions")
	private ArrayList<Sessions> sessions;


	public String getRemote_addr() {
		return remote_addr;
	}


	public void setRemote_addr(String remote_addr) {
		this.remote_addr = remote_addr;
	}


	public String getLocal_addr() {
		return local_addr;
	}


	public void setLocal_addr(String local_addr) {
		this.local_addr = local_addr;
	}


	public ArrayList<Sessions> getSessions() {
		return sessions;
	}


	public void setSessions(ArrayList<Sessions> sessions) {
		this.sessions = sessions;
	}


	@Override
	public String toString() {
		return "Proxy [remote_addr=" + remote_addr + ", local_addr=" + local_addr + ", sessions=" + sessions + "]";
	}


}
