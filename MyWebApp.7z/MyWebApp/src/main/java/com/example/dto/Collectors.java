package com.example.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="collectors")
@XmlAccessorType(XmlAccessType.FIELD)
public class Collectors 
{
	private String name;
	@XmlElement(name="collector")
	private ArrayList<Collector> collector;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Collector> getCollector() {
		return collector;
	}
	public void setCollector(ArrayList<Collector> collector) {
		this.collector = collector;
	}
	@Override
	public String toString() {
		return "Collectors [name=" + name + ", collector=" + collector + "]";
	}
	
	
	
	
	
	


}
