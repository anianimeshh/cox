package com.example.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="sessions")
@XmlAccessorType(XmlAccessType.FIELD)
public class Sessions 
{
	private String name;
	@XmlElement(name="collectors")
	private ArrayList<Collectors> collectors;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Collectors> getCollectors() {
		return collectors;
	}
	public void setCollectors(ArrayList<Collectors> collectors) {
		this.collectors = collectors;
	}
	@Override
	public String toString() {
		return "Sessions [name=" + name + ", collectors=" + collectors + "]";
	}

}
