package com.example.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement(name="ipdrproxy")
public class IpdrProxy 
{


	private ArrayList<Proxy> proxy = new ArrayList<Proxy>();

	public ArrayList<Proxy> getProxy() {
		return proxy;
	}

	public void setProxy(ArrayList<Proxy> proxy) {
		this.proxy = proxy;
	}

	@Override
	public String toString() {
		return "IpdrProxy [proxy=" + proxy + "]";
	}


}
