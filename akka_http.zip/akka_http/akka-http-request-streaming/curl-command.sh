curl -X POST -H "Content-type: application/json" -H "Transfer-Encoding: chunked" -d "@request.json" http://localhost:8080
